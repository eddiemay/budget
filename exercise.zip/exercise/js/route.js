var org = org || {};
org.jw = org.jw || {};
org.jw.exercise = org.jw.exercise || {};

org.jw.exercise.router = function($routeProvider) {
	$routeProvider
		.when('/users', {
				controller: 'UsersCtrl',
				controllerAs: 'usersCtrl',
				template: '<div data-list-users="usersCtrl.users"></div>'
		}).when('/user/:id', {
				controller: 'UserCtrl',
				controllerAs: 'userCtrl',
				template: '<div><a href="#users"><button>Back</button></a>'
                  + '  <h2>{{userCtrl.user.name}}</h2>'
                  + '  <h3>{{userCtrl.user.username}}</h3>'
                  + '  <h3>{{userCtrl.user.email}}</h3>'
                  + '  <h3><address-comp address="userCtrl.user.address"></address-comp></h3>'
                  + '<div id="map-canvas"></div>'
		}).otherwise({ redirectTo: '/users'});
};