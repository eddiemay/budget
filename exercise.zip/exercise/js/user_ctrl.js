org.jw.exercise.UserCtrl = function($routeParams, userService) {
  this.userId = parseInt($routeParams.id, 10);
  this.userService = userService;
  this.refresh();
};

org.jw.exercise.UserCtrl.prototype.userService;
org.jw.exercise.UserCtrl.prototype.userId;
org.jw.exercise.UserCtrl.prototype.user;

org.jw.exercise.UserCtrl.prototype.refresh = function() {
  this.userService.get(this.userId, function(user) {
    this.user = user;
    this.loadMap();
  }.bind(this), function(response) {
    console.log('Error fetching user ' + this.userId);
  }.bind(this));
};

org.jw.exercise.UserCtrl.prototype.loadMap = function() {
  var geo = this.user.address.geo;
  var latLng = new google.maps.LatLng(geo.lat, geo.lng);
  var mapOptions = {
    center: latLng,
    zoom: 9,
    mapTypeId: google.maps.MapTypeId.ROADMAP
  };
  var map = new google.maps.Map(document.getElementById("map-canvas"), mapOptions);
  new google.maps.Marker({
    position: latLng,
    map: map,
    icon: 'http://icons.iconarchive.com/icons/milosz-wlazlo/boomy/16/user-icon.png',
    title: this.user.name
  });
};