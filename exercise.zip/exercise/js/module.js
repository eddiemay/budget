org.jw.exercise.module = angular.module('exercise', ['ngRoute']);

org.jw.exercise.module.config(org.jw.exercise.router);

org.jw.exercise.module.service("userService", org.jw.exercise.UserService);

org.jw.exercise.module.controller("UsersCtrl", org.jw.exercise.UsersCtrl);
org.jw.exercise.module.controller("UserCtrl", org.jw.exercise.UserCtrl);

org.jw.exercise.module.directive("listUsers", function() {
  return {
    restrict: 'AE',
    replace: true,
    scope: {
      listUsers: '='
    },
    template: '<table><tr><th>Name</th><th>Username</th><th>E-mail</th><th>Address</th></tr>'
              + '  <tr data-ng-repeat="user in listUsers | orderBy:\'-name\'">'
              + '    <td><a href="#user/{{user.id}}">{{user.name}}</a></td><td>{{user.username}}</td><td>{{user.email}}</td>'
              + '    <td><address-comp address="user.address"></address-comp></td></tr>'
              + '</table>',
  };
});

org.jw.exercise.module.component('addressComp', {
  template: '<span>{{$ctrl.address.street}} {{$ctrl.address.suite}}<br>'
      + '{{$ctrl.address.city}}, {{$ctrl.address.state}} {{$ctrl.address.zipcode}}</span>',
  bindings: {
    address: '='
  }
});