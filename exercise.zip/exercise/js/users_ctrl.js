org.jw.exercise.UsersCtrl = function(userService) {
  this.userService = userService;
  this.refresh();
};

org.jw.exercise.UsersCtrl.prototype.userService;
org.jw.exercise.UsersCtrl.prototype.users;

org.jw.exercise.UsersCtrl.prototype.refresh = function() {
  this.userService.list(function(users) {
    this.users = users;
  }.bind(this), function(response) {
    console.log('Error fetching users');
  });
};