org.jw.exercise.UserService = function($http) {
  this.$http = $http;
};

org.jw.exercise.UserService.prototype.$http;

org.jw.exercise.UserService.prototype.list = function(successCallback, errorCallback) {
  this.$http({
    method: 'GET',
    url: 'http://jsonplaceholder.typicode.com/users',
  }).then(function(response) {
      successCallback(response.data);
    },
    function(response) {
      console.log('Status code: ' + response.status);
      errorCallback(response);
  });
};

org.jw.exercise.UserService.prototype.get = function(userId, successCallback, errorCallback) {
  this.$http({
    method: 'GET',
    url: 'http://jsonplaceholder.typicode.com/users/' + userId,
  }).then(function(response) {
      successCallback(response.data);
    },
    function(response) {
      console.log('Status code: ' + response.status);
      errorCallback(response);
  });
};